'use client';
import { usePathname } from 'next/navigation';
import Menu from '@/components/admin/Menu';
import AdminHeader from '@/components/admin/AdminHeader';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isLoginPage = pathname === '/admin/login';

  return (
    <div className="flex">
      {!isLoginPage && <Menu/>}
      <main className="flex-1">
        {!isLoginPage && <AdminHeader/>}
        {children}
      </main>
    </div>
  );
}